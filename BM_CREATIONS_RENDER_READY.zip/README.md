# B.M. CREATIONS Public Flipbooks

Static archive prepared for Render.

Render settings:
- Build Command: leave blank
- Publish Directory: .
- Branch: main

The archive opens from index.html.
